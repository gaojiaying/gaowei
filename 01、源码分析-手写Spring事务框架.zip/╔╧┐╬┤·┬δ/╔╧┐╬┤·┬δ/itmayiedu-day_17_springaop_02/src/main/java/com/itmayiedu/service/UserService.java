package com.itmayiedu.service;

//user 服务层
public interface UserService {

	public void add();
}
