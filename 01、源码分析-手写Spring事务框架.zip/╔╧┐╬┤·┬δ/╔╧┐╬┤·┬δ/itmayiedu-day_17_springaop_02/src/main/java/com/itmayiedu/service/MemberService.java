package com.itmayiedu.service;

public interface MemberService {

	public void memberAdd();
}
