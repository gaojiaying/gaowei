package com.itmayiedu.service.impl;

import com.itmayiedu.service.MemberService;

public class MemberServiceImpl implements MemberService {

	public void memberAdd() {
		System.out.println("memberAdd");

	}

}
