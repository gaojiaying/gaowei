package com.itmayiedu.aop;

// 切面类
public class AogLog {

}
